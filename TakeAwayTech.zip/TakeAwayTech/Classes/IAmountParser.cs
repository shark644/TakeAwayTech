﻿namespace TakeAwayTech.Classes
{
    public interface IAmountParser
    {
        string GetAmountInWords(double amount);
    }
}